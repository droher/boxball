This repository contains a version of the Retrosheet historical data
(from http://www.retrosheet.org) maintained by Chadwick Baseball Bureau.

The terms of use for the Retrosheet data apply to this data as well, namely:

     The information used here was obtained free of
     charge from and is copyrighted by Retrosheet.  Interested
     parties may contact Retrosheet at "www.retrosheet.org".

In this repository, the branch 'official' contains the latest official upstream
