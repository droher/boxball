The Lahman Baseball Database

2014 Version
Release Date: January 24, 2015

----------------------------------------------------------------------

README CONTENTS
0.1 Copyright Notice
0.2 Contact Information
